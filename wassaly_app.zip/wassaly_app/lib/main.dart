import 'package:flutter/material.dart';

void main() {
  runApp(const WassalyApp());
}

class WassalyApp extends StatelessWidget {
  const WassalyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'وصلي',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        scaffoldBackgroundColor: const Color(0xFFF9F9F9),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFEF6C1A),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;

  final categories = const [
    _Category('شحن طرود', Icons.inventory_2_outlined, Color(0xFFFFE4C7)),
    _Category('صيدلية', Icons.local_pharmacy_outlined, Color(0xFFDFF4E7)),
    _Category('سوبر ماركت', Icons.shopping_cart_outlined, Color(0xFFE4F1E7)),
    _Category('مطاعم', Icons.lunch_dining_outlined, Color(0xFFFFE4D0)),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(child: _header()),
              SliverToBoxAdapter(child: _search()),
              SliverToBoxAdapter(child: _categories()),
              SliverToBoxAdapter(child: _banner()),
              SliverToBoxAdapter(
                child: _sectionTitle('أفضل المطاعم بالقرب منك', 'المحلية'),
              ),
              SliverToBoxAdapter(child: _restaurants()),
              SliverToBoxAdapter(
                child: _sectionTitle('صيدليات قريبة', 'عرض الكل'),
              ),
              SliverToBoxAdapter(child: _pharmacy()),
              const SliverToBoxAdapter(child: SizedBox(height: 90)),
            ],
          ),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedIndex,
          onDestinationSelected: (i) => setState(() => selectedIndex = i),
          backgroundColor: Colors.white,
          indicatorColor: const Color(0xFFFFE2CC),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home),
              label: 'الرئيسية',
            ),
            NavigationDestination(
              icon: Icon(Icons.search),
              label: 'بحث',
            ),
            NavigationDestination(
              icon: Icon(Icons.receipt_long_outlined),
              label: 'طلباتي',
            ),
            NavigationDestination(
              icon: Icon(Icons.person_outline),
              label: 'الحساب',
            ),
          ],
        ),
      ),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.06),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                )
              ],
            ),
            child: const Icon(Icons.notifications_none_rounded),
          ),
          const Spacer(),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Row(
                children: [
                  const Text(
                    'وصلي',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF5A2D16),
                    ),
                  ),
                  const SizedBox(width: 7),
                  _logoMark(),
                ],
              ),
              const Text(
                'Wassaly',
                style: TextStyle(
                  fontSize: 12,
                  color: Color(0xFF777777),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _logoMark() {
    return SizedBox(
      width: 30,
      height: 25,
      child: Stack(
        children: [
          Positioned(
            top: 2,
            right: 0,
            child: _line(24, const Color(0xFF2F9B6C)),
          ),
          Positioned(
            top: 9,
            right: 5,
            child: _line(20, const Color(0xFFF49A35)),
          ),
          Positioned(
            top: 16,
            right: 10,
            child: _line(14, const Color(0xFF2F9B6C)),
          ),
        ],
      ),
    );
  }

  Widget _line(double width, Color color) {
    return Container(
      width: width,
      height: 4,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
    );
  }

  Widget _search() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: TextField(
        textDirection: TextDirection.rtl,
        decoration: InputDecoration(
          hintText: 'ابحث عن مطعم، سوبر ماركت...',
          prefixIcon: const Icon(Icons.search),
          filled: true,
          fillColor: Colors.white,
          contentPadding:
              const EdgeInsets.symmetric(vertical: 15, horizontal: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _categories() {
    return SizedBox(
      height: 112,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 8),
        scrollDirection: Axis.horizontal,
        reverse: true,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) {
          final item = categories[i];
          return SizedBox(
            width: 82,
            child: Column(
              children: [
                Container(
                  width: 62,
                  height: 62,
                  decoration: BoxDecoration(
                    color: item.color,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Icon(item.icon, size: 31, color: const Color(0xFF333333)),
                ),
                const SizedBox(height: 7),
                Text(
                  item.name,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _banner() {
    return Container(
      height: 145,
      margin: const EdgeInsets.fromLTRB(18, 4, 18, 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFF7B22), Color(0xFFFF9A25)],
          begin: Alignment.centerRight,
          end: Alignment.centerLeft,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -12,
            bottom: -20,
            child: Icon(
              Icons.local_offer_rounded,
              size: 115,
              color: Colors.white.withOpacity(.13),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: const [
                      Text(
                        'خصم 50%',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 27,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        'على أول طلب!',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(
                  Icons.shopping_bag_outlined,
                  size: 72,
                  color: Colors.white,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title, String action) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
      child: Row(
        children: [
          Text(
            action,
            style: const TextStyle(
              color: Color(0xFFE86D20),
              fontWeight: FontWeight.w800,
              fontSize: 13,
            ),
          ),
          const Spacer(),
          Text(
            title,
            style: const TextStyle(
              fontSize: 19,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  Widget _restaurants() {
    final data = [
      ('البركة للبرجر', 'برجر', '4.8', '30-35 دقيقة', Icons.lunch_dining),
      ('كشري أبو طارق', 'كشري', '4.8', '30-35 دقيقة', Icons.rice_bowl),
      ('البركة للبرجر', 'وجبات', '4.8', '30-35 دقيقة', Icons.fastfood),
    ];

    return SizedBox(
      height: 205,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 18),
        scrollDirection: Axis.horizontal,
        reverse: true,
        itemCount: data.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) {
          final x = data[i];
          return Container(
            width: 178,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.05),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  height: 100,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF4E2D0),
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(18),
                    ),
                  ),
                  child: Center(
                    child: Icon(x.$5, size: 54, color: const Color(0xFFB76B35)),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
                  child: Text(
                    x.$1,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  child: Row(
                    children: [
                      const Icon(Icons.star, size: 15, color: Color(0xFFFFA000)),
                      const SizedBox(width: 3),
                      Text(x.$3, style: const TextStyle(fontSize: 12)),
                      const Spacer(),
                      Text(x.$4, style: const TextStyle(fontSize: 11)),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _pharmacy() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 18),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: const BoxDecoration(
              color: Color(0xFFE4F2E9),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.local_pharmacy,
              color: Color(0xFF248A62),
              size: 30,
            ),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  'صيدلية العزيبي',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                ),
                SizedBox(height: 5),
                Text(
                  '4.8 ⭐  •  25-30 دقيقة',
                  style: TextStyle(color: Colors.black54, fontSize: 12),
                ),
              ],
            ),
          ),
          FilledButton(
            onPressed: null,
            style: ButtonStyle(
              backgroundColor:
                  WidgetStatePropertyAll(Color(0xFFE96F21)),
              foregroundColor: WidgetStatePropertyAll(Colors.white),
              padding: WidgetStatePropertyAll(
                EdgeInsets.symmetric(horizontal: 13),
              ),
            ),
            child: Text('اطلب الآن'),
          ),
        ],
      ),
    );
  }
}

class _Category {
  final String name;
  final IconData icon;
  final Color color;

  const _Category(this.name, this.icon, this.color);
}
